# sharefile

Uploads files to s3 and provides access via rss

```bash
helm repo add sharefile https://paragor.github.io/sharefile
helm repo update
helm install my-todo sharefile/sharefile --version 0.0.1
```


all information in code  https://github.com/paragor/sharefile
